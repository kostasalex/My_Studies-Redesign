export { default as Header } from './common/header/Header';
export { default as Footer } from './common/footer/Footer';
export { default as Guest } from './UserSpecific/guest/Guest';
export { default as Student } from './UserSpecific/student/Student';
export { default as Teacher } from './UserSpecific/teacher/Teacher';
export { default as Contact } from './common/contact/contactForm.jsx';
export { default as Faq } from './common/faq/Faq.jsx';
